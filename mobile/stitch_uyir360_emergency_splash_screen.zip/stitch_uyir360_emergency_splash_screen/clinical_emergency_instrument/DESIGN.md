---
name: Clinical Emergency Instrument
colors:
  surface: '#23524c'
  surface-dim: '#001715'
  surface-bright: '#213e3b'
  surface-container-lowest: '#00110f'
  surface-container-low: '#01201d'
  surface-container: '#042421'
  surface-container-high: '#102f2c'
  surface-container-highest: '#1c3a36'
  on-surface: '#c8e9e4'
  on-surface-variant: '#bdc9c2'
  inverse-surface: '#c8e9e4'
  inverse-on-surface: '#173532'
  outline: '#87948d'
  outline-variant: '#3e4944'
  surface-tint: '#74d9b6'
  primary: '#ffffff'
  on-primary: '#003829'
  primary-container: '#91f6d1'
  on-primary-container: '#007257'
  inverse-primary: '#006c52'
  secondary: '#77d7c8'
  on-secondary: '#003731'
  secondary-container: '#007e71'
  on-secondary-container: '#c9fff5'
  tertiary: '#ffffff'
  on-tertiary: '#003732'
  tertiary-container: '#bbece4'
  on-tertiary-container: '#3e6c66'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#91f6d1'
  primary-fixed-dim: '#74d9b6'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#00513d'
  secondary-fixed: '#93f4e4'
  secondary-fixed-dim: '#77d7c8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#bbece4'
  tertiary-fixed-dim: '#a0d0c8'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#1f4e48'
  background: '#001715'
  on-background: '#c8e9e4'
  surface-variant: '#1c3a36'
  canvas: '#072724'
  canvas-raised: '#0f3933'
  surface-alt: '#1c3f38'
  atmosphere-deep: '#122d28'
  hairline: '#2c2e33'
  text-primary: '#ffffff'
  text-secondary: '#b0c5c1'
  status-stable: '#97fcd7'
  status-caution: '#eac486'
  status-critical: '#ff4d4d'
  accent-stroke: '#33998c'
  light-canvas: '#ffffff'
  light-band: '#ebe7e1'
  light-muted: '#8c9ba0'
  light-ink: '#222222'
  hard-black: '#000000'
typography:
  vital-readout:
    fontFamily: Inter
    fontSize: 96px
    fontWeight: '700'
    lineHeight: 86px
    letterSpacing: normal
  vital-readout-mobile:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 58px
    letterSpacing: normal
  display:
    fontFamily: Playfair Display
    fontSize: 72px
    fontWeight: '400'
    lineHeight: 72px
    letterSpacing: normal
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: normal
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: normal
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: normal
  headline-md:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: normal
  headline-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: normal
  title-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: normal
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: normal
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 21px
    letterSpacing: normal
  label-eyebrow:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.1em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: normal
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 2.5rem
  space-3xl: 3rem
  space-4xl: 4rem
  space-5xl: 5rem
  space-6xl: 7.5rem
---

Uyir360 — Style Reference
a dark instrument that goes silent, then screams
Theme: dark
Uyir360 reads as a calm, dark clinical instrument — a near-monochrome forest canvas carrying a single cool mint accent — engineered to hold that composure right up until a life is actually at risk, at which point the entire interface breaks its own rules and turns unmissable red. The system is built around a strict three-state traffic-light logic (stable / caution / critical) that governs almost every color decision on screen, so the interface communicates patient status before a single word is read. Typography stays sans-serif and heavy-weighted everywhere a value is being read under stress; a serif appears only at the brand moment and inside the calm post-incident report, never inside the live flow. Pill-shaped controls handle every ordinary action, while a single deliberately non-pill, blocky red panel exists for exactly one purpose — starting CPR — so it can never be mistaken for anything else in the app.
Tokens — Colors
Name Value Token Role Canvas #072724 --color-canvas Page canvas, hero background — the dominant dark field everything else sits on Canvas Raised #0f3933 --color-canvas-raised Secondary dark surface, strong borders Surface #23524c --color-surface Default card fill, one step lighter than canvas for layer separation Surface Alt #1c3f38 --color-surface-alt Secondary/atmosphere surface, mid-tone background shapes Atmosphere Deep #122d28 --color-atmosphere-deep Deepest background tint behind organic hero shapes Hairline #2c2e33 --color-hairline 1px dividers and default borders across cards and icons — almost invisible on the dark canvas, used for structural quietness Text Primary #ffffff --color-text-primary Headline text and vital numerals on dark canvas Text Secondary #b0c5c1 --color-text-secondary Body copy, captions, muted descriptions — desaturated enough to recede behind status color Status Stable #97fcd7 --color-status-stable Traffic-light GREEN — normal vitals, primary confirm actions, nav pills, links Status Caution #eac486 --color-status-caution Traffic-light AMBER — deteriorating trend, low-confidence signal, contact-pressure guidance Status Critical #ff4d4d --color-status-critical Traffic-light RED — asystole/no-pulse detected, START CPR state, hard stops. Reserved exclusively for life-critical alerts, never decorative Accent Stroke #33998c --color-accent-stroke Mid-saturation teal for SVG strokes, waveform lines, hover/transition states Light Canvas #ffffff --color-light-canvas Incident Report base — the one screen in the system that isn't dark Light Band #ebe7e1 --color-light-band Calm parchment content band for printable/shareable incident summaries Light Muted #8c9ba0 --color-light-muted Muted text and borders on light surfaces Light Ink #222222 --color-light-ink Primary text on light surfaces Hard Black #000000 --color-hard-black Input borders, fine icon fills on light surfaces. Used sparingly as a true-black anchor
Tokens — Typography
Inter — Body, UI labels, navigation, buttons, captions, and every numeral inside the live-emergency flow. Weight floor raised to 400 (never below) so the interface stays legible with adrenaline and shaking hands; 600–700 carries interactive controls, CTA labels, and vital readouts. · --font-inter
Substitute: system-ui, -apple-system, 'Helvetica Neue', Roboto
Weights: 400, 500, 600, 700
Sizes: 12px, 14px, 16px, 20px, 24px, 32px, 48px, 96px
Line height: 0.9 at 96px (tabular vital readout), 1.1–1.2 at 32–48px, 1.3–1.5 below 24px
Letter spacing: normal, except uppercase eyebrow labels at 0.08–0.12em
Numeric features: tabular-nums on every live-updating value, so digits don't shift the layout as they refresh
Role: the only font family permitted inside contact, triage, CPR, and relay screens.
Teodor — Splash/brand lockup and Incident Report headlines exclusively. Never appears inside the live-emergency flow. · --font-teodor
Substitute: Tiempos Headline, Recoleta, Playfair Display
Weights: 400
Sizes: 28px, 72px
Line height: 1.0 at 72px, 1.2 at 28px
Letter spacing: normal
Role: the single editorial gesture in the whole system — used exactly twice (app-name lockup, report headline) so it stays a moment rather than a habit.
Type Scale
Role Size Line Height Weight Token caption 12px 1.5 400 --text-caption body-sm 14px 1.5 400 --text-body-sm body 16px 1.5 400 --text-body subheading 20px 1.3 500 --text-subheading heading-sm 24px 1.3 600 --text-heading-sm heading 32px 1.2 600 --text-heading heading-lg 48px 1.1 700 --text-heading-lg display 72px 1.0 400 (Teodor) --text-display vital-readout 96px 0.9 700, tabular-nums --text-vital
Tokens — Spacing & Shapes
Base unit: 8px
Density: spare in the live-emergency flow, comfortable in Clinician Mode and the Incident Report
Spacing Scale
Name Value Token 4 4px --spacing-4 8 8px --spacing-8 12 12px --spacing-12 16 16px --spacing-16 20 20px --spacing-20 24 24px --spacing-24 32 32px --spacing-32 40 40px --spacing-40 48 48px --spacing-48 64 64px --spacing-64 80 80px --spacing-80 120 120px --spacing-120
Border Radius
Element Value inputs / chips 8px standard cards 12px critical action panel 24px buttons / tags / nav pills 60px
Layout
Page max-width: 480px (mobile-first, single-hand emergency reach)
Section gap: 32–48px
Card padding: 20–24px
Element gap: 16px
