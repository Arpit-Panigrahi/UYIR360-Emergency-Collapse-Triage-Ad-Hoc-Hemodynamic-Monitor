---
name: Clinical Precision Dark
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3d'
  surface-container-lowest: '#0b0f12'
  surface-container-low: '#181c1f'
  surface-container: '#1c2023'
  surface-container-high: '#262a2e'
  surface-container-highest: '#313539'
  on-surface: '#e0e3e7'
  on-surface-variant: '#c1c8c1'
  inverse-surface: '#e0e3e7'
  inverse-on-surface: '#2d3134'
  outline: '#8b938c'
  outline-variant: '#414943'
  surface-tint: '#a4d1b4'
  primary: '#daffe6'
  on-primary: '#0d3824'
  primary-container: '#b7e4c7'
  on-primary-container: '#3e6750'
  inverse-primary: '#3e6750'
  secondary: '#9dd1c1'
  on-secondary: '#00382d'
  secondary-container: '#1e5145'
  on-secondary-container: '#8fc3b3'
  tertiary: '#fff3f0'
  on-tertiary: '#53210c'
  tertiary-container: '#ffcfbe'
  on-tertiary-container: '#8c4e36'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c0edd0'
  primary-fixed-dim: '#a4d1b4'
  on-primary-fixed: '#002112'
  on-primary-fixed-variant: '#264f39'
  secondary-fixed: '#b8eedd'
  secondary-fixed-dim: '#9dd1c1'
  on-secondary-fixed: '#002019'
  on-secondary-fixed-variant: '#1b4f43'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#6f3720'
  background: '#101417'
  on-background: '#e0e3e7'
  surface-variant: '#313539'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 32px
  label-telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is engineered for high-acuity clinical emergency environments where clarity, rapid cognition, and zero cognitive fatigue are critical. Operating in emergency triage, intensive care units, and acute trauma monitoring, clinicians require an environment devoid of visual noise, simulated physical depth, or distracting fluorescent luminescence.

The aesthetic direction aligns with a restrained, technical **Minimalist Flat** framework tailored for dark operational theaters:
- **Zero Distraction:** Eliminates all decorative drop shadows, box shadows, volumetric glows, and saturated halogen accents.
- **Clinically Restrained Palette:** Transitions from hyper-saturated neon monitors to muted, calming botanical sages and balanced neutrals that signal stability and precision without causing retinal strain during extended low-light shifts.
- **Structural Integrity:** Employs precise, structural hairline boundaries and micro-tonal shifts to establish separation, elevating telemetry, vital signs, and diagnostic workflows to immediate legibility.

## Colors

The palette is anchored in deep, light-absorbent charcoal and graphite surfaces that mitigate ambient glare in darkened clinical rooms. The previous high-saturation mint is replaced with a balanced, gentle pastel sage/mint (`#B7E4C7`), providing high contrast against dark substrates without radiant bloom.

### Palette Architecture
- **Primary (`#B7E4C7` - Pastel Sage):** Denotes primary interactive states, confirmed telemetry values, stable status indicators, and baseline selections. Delivers high contrast text and iconography without luminescent flaring.
- **Secondary (`#76A99A` - Muted Sea Slate):** Handles secondary utility accents, sub-metric metadata, baseline graphs, and inactive operational tabs.
- **Tertiary (`#E29578` - Muted Terracotta):** Calibrated clinical alert color used strictly for urgent triage status, cautionary thresholds, and time-critical overrides. Avoids pure radioactive neon reds to prevent sensory alarm fatigue.
- **Neutral Surface Canvas (`#0D1215` / `#111518` / `#161A1D`):** Deep graphite layers. `#0D1215` serves as the canvas substrate, `#111518` as the primary card surface, and `#161A1D` as elevated utility panels or table rows.
- **Borders & Dividers (`#252C32` / `#2F373E`):** Hairline structure dividers maintaining 1px crisp geometry without luminous feathering.
- **Text & Telemetry:**
  - Primary text: `#EDF2F4` (High legibility off-white).
  - Secondary text: `#9CAAB5` (Soft slate grey).
  - Disabled / Muted: `#505C66`.

## Typography

Typography balances rapid scanning with clinical precision.

1. **Display & Section Headers (Space Grotesk):** Engineered structural geometry that introduces authority and immediate legibility for patient triage tiers and module headers.
2. **Body & Diagnostic Narrative (Geist):** Clean, neutral grotesque engineered specifically for high screen density and legibility in micro-contrast environments.
3. **Telemetry, Timestamps, & Data Points (JetBrains Mono):** Tabular, monospaced numeric data ensuring heart rate, oxygen saturation, drug dosages, and countdown clocks align mechanically across rapid tabular refreshes without layout jitter.

## Layout & Spacing

A compact, disciplined 12-column grid provides deterministic screen real estate allocation across triage workstations, tablet carts, and handheld diagnostic terminals.

- **Grid Architecture:** 12-column fluid grid on desktop viewports (>1024px) with `1rem` gutters and `1.5rem` margins. Adapts to 8-column layout on tablet devices and 4-column layout on handheld mobile screens with `1rem` canvas margins.
- **Rhythm & Information Density:** Tight `0.5rem` (`space-sm`) and `0.25rem` (`space-xs`) internal component gaps prioritize high-density data display without visual crowding.
- **Structural Separation:** Panels and dashboards separate via precise 1px hairline guides rather than expansive empty space, maximizing data accessibility above the fold.

## Elevation & Depth

This system operates entirely on **planar tonal layering and low-contrast outlines**. 

- **Zero Shadows:** All CSS `box-shadow`, `drop-shadow`, and `filter: drop-shadow(...)` rules are strictly prohibited. Cards, overlays, modals, and tooltips have no shadows.
- **Zero Luminescence & Glows:** No `text-shadow`, blurred color borders, or radial ambient glows are permitted, ensuring ambient clinical lighting is not combated with unnecessary screen halation.
- **Depth via Tiers:**
  - **Base Canvas:** `#0D1215` (Deepest layer).
  - **Primary Card Surface:** `#111518` framed by a subtle 1px border (`#252C32`).
  - **Floating Panels / Modals / Active Row States:** `#161A1D` with a crisp 1px border (`#2F373E`).
- **Hairline Precision:** Surfaces distinguish themselves strictly through exact color steps between `#0D1215`, `#111518`, and `#161A1D`, bounded by unblurred 1px solid borders.

## Shapes

The design system employs a restrained **Soft (`1`)** shape language:
- Standard interactive elements (buttons, inputs, status badges, and cards) use subtle `0.25rem` (4px) corner radiuses.
- Larger groupings and modal frames use `rounded-lg` (`0.5rem` / 8px).
- Pill shapes and extreme roundings are prohibited for core clinical readouts and containers to maintain maximum internal grid efficiency and reinforce an authoritative, instrument-grade interface.

## Components

### 1. Buttons
- **Primary Button:** Solid pastel sage fill (`#B7E4C7`) with dark charcoal text (`#0D1215`), font-weight 600. Flat surface, strictly zero box-shadow or outer glow. Hover state transitions background to `#A3D9B5`. Active state: `#8EC9A2`.
- **Secondary Button:** Surface `#161A1D` with 1px border in `#2F373E`, text in `#EDF2F4`. Hover state transitions border to `#76A99A`.
- **Destructive / Urgent Action:** Deep charcoal `#1A1414` surface with a 1px border in `#E29578` and text in `#E29578`. Zero glowing effects.

### 2. Cards & Clinical Panels
- Constructed with `#111518` background and a solid 1px border in `#252C32`.
- Completely flat: no drop-shadows or border-glow highlights.
- Panel headers use a 1px bottom border in `#252C32` with typography in `Space Grotesk` (`headline-sm`).

### 3. Vital Sign Readouts & Telemetry Tiles
- Telemetry numbers are displayed in `JetBrains Mono` (`label-telemetry-lg`).
- Data values rest flat against `#111518` surfaces.
- Normal state: Text rendered in pastel sage (`#B7E4C7`). No blurred ambient glow under numbers.
- Warning state: Text rendered in muted terracotta (`#E29578`) with a flat background tint of `#211816`.

### 4. Chips & Badges
- **Triage Badges:** Height 22px, corner radius 4px (`0.25rem`). Flat 1px border.
- **Normal Status:** Border in `#76A99A`, text in `#B7E4C7`, background `#121B18`.
- **Critical Status:** Border in `#E29578`, text in `#E29578`, background `#1E1513`.
- No outer halos or pulsating blurred rings. Pulsing states, if required, must be represented solely by solid border-color toggles or discrete icon state shifts.

### 5. Input Fields
- Background `#0D1215` with a 1px solid border in `#252C32`. Text in `#EDF2F4`, placeholder in `#505C66`.
- **Focus State:** 1px solid border in pastel sage (`#B7E4C7`). Explicitly no focus-ring glow, offset shadow, or blurred outline.

### 6. Checkboxes & Radio Buttons
- 16px × 16px squares (checkbox) or circles (radio) with `#0D1215` background and 1px border in `#2F373E`.
- **Checked State:** Background `#B7E4C7` with crisp dark `#0D1215` checkmark icon. No outer radial emission.

### 7. Tables & Patient Lists
- Dense tabular rows with `#111518` backgrounds separated by 1px `#252C32` horizontal lines.
- Hover row state changes background strictly to `#161A1D` with no elevation change or z-index shadow projection.